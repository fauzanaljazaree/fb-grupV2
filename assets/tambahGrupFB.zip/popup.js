document.getElementById("startBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: autoSelectGroups,
  });
});

async function autoSelectGroups() {
  // Helper: delay acak agar terlihat natural seperti manusia (berbasis KLM research)
  // Basis: M mental ~1350ms, P pointing ~1100ms, K click ~230ms (Card, Moran & Newell)
  const rand = (min, max) => min + Math.random() * (max - min);

  const humanDelay = (min = 600, max = 2600) =>
    new Promise((resolve) => setTimeout(resolve, rand(min, max)));

  // Ritme klik manusia saat checklist: dominan ritmis-cepat, sesekali berhenti membaca
  // (distribusi miring 70/30, bukan uniform) — rata-rata jatuh ~1.3s ≈ P+K+M manusia
  const humanClickDelay = () =>
    new Promise((resolve) => setTimeout(resolve, Math.random() < 0.7 ? rand(600, 1400) : rand(1400, 2600)));

  // 1. Query document-wide — terbukti lewat diagnostik: FB me-render daftar grup via
  //    React PORTAL di luar subtree dialog (checkboxesDiDalamPicker = 0),
  //    jadi scope ketat ke dialog selalu menghasilkan 0 item.
  const checkboxes = Array.from(document.querySelectorAll('input[type="checkbox"]'));

  if (checkboxes.length === 0) {
    alert("Daftar grup/checkbox tidak ditemukan!");
    return;
  }

  // 2. Filter multi-lapis agar tidak pernah klik toggle "Posting secara anonim"
  //    dan hanya mengambil item GRUP (tervalidasi lewat HTML & diagnostik):
  //    a) Buang role="switch"  → toggle anonim (roleSwitchCount = 1, checkbox grup tidak punya role)
  //    b) Buang disabled       → toggle anonim punya disabled, checkbox grup tidak
  //    c) WAJIB punya foto     → wrapper [role="button"] tiap item grup mengandung <svg>/<image>/<img>
  //                              (tervalidasi 3/3 sampel: punyaFoto=true), toggle anonim tidak punya foto
  //    d) Fallback teks "anonim" → jaring pengaman terakhir
  const isGroupCheckbox = (checkbox) => {
    if (checkbox.getAttribute("role") === "switch") return false;
    if (checkbox.disabled) return false;
    const wrapper = checkbox.closest('[role="button"]');
    if (!wrapper) return false;
    if (!wrapper.querySelector('svg, image, img')) return false;
    const text = wrapper.innerText ? wrapper.innerText.toLowerCase() : "";
    if (text.includes("anonim") || text.includes("anonymous")) return false;
    return true;
  };

  const groupCheckboxes = checkboxes.filter(isGroupCheckbox);

  // Ambil maksimal 9 checkbox grup pertama
  const targetCheckboxes = groupCheckboxes.slice(0, 9);

  if (targetCheckboxes.length === 0) {
    alert("Daftar grup tidak ditemukan (tidak ada item grup yang lolos filter)!");
    return;
  }
  let checkedCount = 0;

  // 2. Checklist satu per satu secara sekuensial dengan jeda acak
  for (const checkbox of targetCheckboxes) {
    // Verifikasi elemen masih ada di DOM (Facebook bisa re-render)
    if (!document.contains(checkbox)) continue;

    // Scroll ke item agar terlihat manusia sedang melihat daftar
    checkbox.scrollIntoView({ block: "center", behavior: "smooth" });
    await humanDelay(400, 1200);

    // Verifikasi ulang setelah scroll (re-render bisa menggantikan node)
    if (!document.contains(checkbox)) continue;

    const isAlreadyChecked = checkbox.getAttribute("aria-checked") === "true" || checkbox.checked;
    if (isAlreadyChecked) continue;

    // Cari elemen pembungkus terdekat yang memiliki role="button"
    const clickableContainer = checkbox.closest('[role="button"]');

    if (clickableContainer) {
      clickableContainer.click();
    } else {
      checkbox.click();
    }
    checkedCount++;

    // Jeda ritme klik manusia (70% cepat ritmis, 30% berhenti baca) antar checklist
    await humanClickDelay();
  }

  // 3. Jeda "cek ulang sudah 9 belum ya" sebelum klik tombol "Selesai" (M penuh + visual check)
  await humanDelay(1500, 3500);

  // Strategi Robust: Cari tombol "Selesai" berdasarkan aria-label atau teks konten
  const doneButton = Array.from(document.querySelectorAll('[role="button"]')).find((btn) => {
    const ariaLabel = btn.getAttribute("aria-label");
    const textContent = btn.innerText ? btn.innerText.trim() : "";

    return (ariaLabel && ariaLabel.toLowerCase() === "selesai") || (textContent && textContent.toLowerCase() === "selesai");
  });

  // Verifikasi keberadaan tombol sebelum klik (cegah null reference)
  if (doneButton) {
    doneButton.click();
  } else {
    console.warn('Tombol "Selesai" tidak ditemukan secara otomatis.');
  }
}
